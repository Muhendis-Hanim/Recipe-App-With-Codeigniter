
<?php $this->load->view("includes/header"); ?>

    <div class="container">
        <form action="<?php echo base_url("home/insert"); ?>" method="post" style="margin-bottom: 45px;">
            <div id="input"><label for="">İstediğiniz Malzemeleri Giriniz:</label></div>
            <div class="input-group" style=" max-width: 50%;    margin: auto;">
                <input type="search" class="form-control rounded" placeholder="" name="firstProduct" aria-label="Search"
                       aria-describedby="search-addon"/>
                <button type="submit" class="btn btn-primary">Ekle</button>
            </div>
        </form>

        <div class="row">
            <div class="col">
                <h3>Eklenenler:</h3>
                <?php
                foreach ($rows1 as $row) { ?>
                    <div style="margin-bottom: 15px;">
                        <button type="button" class="btn btn-primary"><?php echo $row->name; ?></button>
                        <a href="<?php echo base_url("home/delete/$row->id"); ?>">
                            <button type="submit" name="submit" class="btn btn-warning">Kaldır</button>
                        </a>
                        <br>
                    </div>
                <?php } ?>
                <form action="<?php echo base_url("home/insert2"); ?>" method="post">
                    <div class="form-group" style="    width: 240px;">
                        <input type="text" class="form-control" placeholder="Ürün Adı" name="product">
                    </div>
                    <div style="margin=15px; ">
                        <button type="submit" class="btn btn-success">Bu Maddelerden Ürün Oluştur</button>
                    </div>
                </form>

            </div>

            <div class="col">
                <h3>Ürün:</h3>
                <?php
                foreach ($rows2 as $row2) { ?>
                    <div style="margin-bottom: 15px;">
                        <button type="button" class="btn btn-primary"><?php echo $row2->name; ?></button>
                        <a href="<?php echo base_url("home/delete2/$row2->id"); ?>">
                            <button type="submit" name="submit" class="btn btn-warning">Kaldır</button>
                        </a>
                        <br>
                    </div>
                <?php } ?>
                <form action="<?php echo base_url("home/insert3"); ?>" method="post">
                    <div class="form-group" style="    width: 240px;">
                        <input type="text" class="form-control" placeholder="Ürün Adı" name="endProduct">
                    </div>
                    <div style="margin=15px; ">
                        <button type="submit" class="btn btn-success">Bu Ürünlerden Yeni Ürün Oluştur</button>
                    </div>
                </form>
            </div>

            <div class="col">
                <h3>Yeni Ürün:</h3>
                <?php
                foreach ($rows3 as $row3) { ?>
                    <div style="margin: 15px;">
                        <button type="button" class="btn btn-primary"><?php echo $row3->name; ?></button>
                        <a href="<?php echo base_url("home/delete3/$row3->id"); ?>">
                            <button type="submit" name="submit" class="btn btn-warning">Kaldır</button>
                        </a>
                        <br>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>

<?php $this->load->view("includes/footer"); ?>