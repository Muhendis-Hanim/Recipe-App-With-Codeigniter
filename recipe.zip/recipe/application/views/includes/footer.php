<div class="container" id="footer">
    <footer class="py-3 my-4">
        <ul class="nav justify-content-center border-bottom pb-3 mb-3">
            <li class="nav-item"><a href="<?php echo base_url("home"); ?>" class="nav-link px-2 text-muted">Anasayfa</a>
            </li>
        </ul>
        <p class="text-center text-muted"> © 2022 Tüm Hakları Saklıdır.</p>
    </footer>
    <script src="<?php echo base_url("assets/js/bootstrap.js"); ?>">
    </script>
</div>
</body>
</html>