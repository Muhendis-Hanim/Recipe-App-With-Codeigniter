<?php
class Home extends CI_Controller{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('product_model');
    }
    public function index(){
        $data['rows1']=$this->product_model->getAll();
        $data['rows2']=$this->product_model->getAllProduct();
        $data['rows3']=$this->product_model->getAllProductThird();
        $this->load->view('index', $data);
    }

    public function insert(){
        $name = $this->input->post('firstProduct');
        $data = array(
            "name" =>$name
        );
        $this->product_model->insert($data);
      redirect(base_url("home"));
    }

    public function insert2(){
        $urun = $this->input->post('product');
        $data = array(
            "name" =>$urun
        );
        $this->product_model->insert2($data);
        redirect(base_url("home"));
    }
    public function insert3(){
        $urun = $this->input->post('endProduct');
        $data = array(
            "name" =>$urun
        );
        $this->product_model->insert3($data);
        redirect(base_url("home"));
    }
    public function delete($id){
        $delete= $this->product_model->delete($id);
    }
    public function delete2($id){
        $delete= $this->product_model->delete2($id);
    }
    public function delete3($id){
        $delete= $this->product_model->delete3($id);
    }
}
?>