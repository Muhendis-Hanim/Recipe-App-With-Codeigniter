<?php
class Product_model extends CI_Model{

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function getAll()
    {
        $query = $this->db->get('matter');
        return $query->result();
    }

    public function getAllProduct()
    {
        $query = $this->db->get('product');
        return $query->result();
    }

    public function getAllProductThird()
    {
        $query = $this->db->get('productthree');
        return $query->result();
    }

    public function insert($data = array())
    {
        $name = $this->input->post('firstProduct');
        $data = array(
            'name' => $name
        );
        $this->db->insert('matter', $data);

    }

    public function insert2($data = array())
    {
        $urun = $this->input->post('product');
        $data = array(
            'name' => $urun
        );
        $this->db->insert('product', $data);
    }

    public function insert3($data = array())
    {
        $urun = $this->input->post('endProduct');
        $data = array(
            'name' => $urun
        );
        $this->db->insert('productthree', $data);
    }

    public function delete($id)
    {
        $delete = $this
            ->db
            ->where("id", $id)
            ->delete("matter");

        if ($delete) {
            redirect(base_url("home"));
        } else {
            echo "Silme İşlemi Hatalı";
        }
    }

    public function delete2($id)
    {
        $delete = $this
            ->db
            ->where("id", $id)
            ->delete("product");

        if ($delete) {
            redirect(base_url("home"));
        } else {
            echo "Silme İşlemi Hatalı";
        }
    }

    public function delete3($id)
    {
        $delete = $this
            ->db
            ->where("id", $id)
            ->delete("productthree");

        if ($delete) {
            redirect(base_url("home"));
        } else {
            echo "Silme İşlemi Hatalı";
        }
    }
}